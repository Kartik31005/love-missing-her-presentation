
import tkinter as tk
from PIL import ImageTk, Image

slides = [
    {"img": "images/img1.jpg", "text": "Every moment without you feels like an eternity."},
    {"img": "images/img2.jpg", "text": "Your smile is the sunshine I miss every day."}
]

class LovePresentation:
    def __init__(self, root):
        self.root = root
        self.root.title("Missing You 💖")
        self.root.geometry("800x600")
        self.root.configure(bg="black")

        self.image_label = tk.Label(self.root, bg="black")
        self.image_label.pack(pady=20)

        self.text_label = tk.Label(self.root, text="", font=("Helvetica", 20, "italic"),
                                   fg="pink", bg="black", wraplength=700, justify="center")
        self.text_label.pack(pady=20)

        self.index = 0
        self.show_slide()

    def show_slide(self):
        if self.index < len(slides):
            img_path = slides[self.index]["img"]
            message = slides[self.index]["text"]

            img = Image.open(img_path)
            img = img.resize((500, 300), Image.ANTIALIAS)
            photo = ImageTk.PhotoImage(img)

            self.image_label.config(image=photo)
            self.image_label.image = photo
            self.text_label.config(text=message)

            self.index += 1
            self.root.after(3000, self.show_slide)
        else:
            self.text_label.config(text="No matter how far, you're always in my heart ❤️")

if __name__ == "__main__":
    root = tk.Tk()
    app = LovePresentation(root)
    root.mainloop()
