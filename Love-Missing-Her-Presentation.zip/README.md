
# 💖 Love Presentation: Missing Her

A simple and emotional Python-based GUI slideshow using Tkinter.

## 🖼️ How to Run

1. Install Pillow if needed:
```
pip install -r requirements.txt
```

2. Run the slideshow:
```
python main.py
```

## 📂 Folder Structure

- `main.py` - Main Python presentation code.
- `images/` - Folder containing love images.
- `requirements.txt` - Python dependencies.
